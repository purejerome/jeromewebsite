/*
 * CS 261: P4 Y86 Interpreter Main driver
 *
 * Name: MUST  WRITE YOUR  FULL NAME HERE 
 *    or risk losing points, and delays when you seek my help during office hours 
 */

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include "p1-check.h"
#include "p2-load.h"
#include "p3-disas.h"
#include "p4-interp.h"

int main (int argc, char **argv)
{
    
    return EXIT_SUCCESS;    

}
